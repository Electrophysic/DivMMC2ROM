10.12.2017 - VELESOFT

DIVRAMKA is memory tester for DivIDE and DivMMC interface. Test all 8kB ram pages in this device.

INFO:
Before testing backup first 32kB of DivXXX ram memory to ZX ram memory from 32768 (need ZX48kB or 128kB)
Fill all DivXXX ram pages with bytes #FF,#00,#AA,#55 and test if all pages contain corresponding values.
After test show result on screen and refresh first 32kB of DivXXX ram from ZX ram 32768. This refresh enable return to DivXXX system without problems (without memory backup will system data in DivXXX ram destroyed...)

For jump to source code break program an in basic write RANDOMIZE USR 30000. Source code is writed in special version of assembler PROMETHEUS (don't use ZX rom).

some controll keys in assembler:
SS+A = assembly
SS+T = show table with labels
SS+T,C = clear table
SS+M = jump to monitor (key Q in monitor return to editor)
SS+B = jump to basic
